import mconst
from mzqllite import *
# from mfile import *
# from mmail import *
from mzweb import *
from moss import *
from mconst import *

MTITLE = "MUZSTAT"


def main():

    param1 = sys.argv[1] if (len(sys.argv) > 1) else False

    status_prod= True  if param1 == TXTPRODUCTIVE else False

    try:

        write_file(MTITLE + " Start " + VER)

        kill_chrome(status_prod)

        db = cDb()

        # db.dbchk2table()

        # db.initstring()

        # mcol_names, mconnection=dbinitialize()

        # mSt=StatString(mcol_names)
        web = cWebm()

        # Отдельная программа - в будущем. Пока отладка в mains.py добавлеение строки в таблицу поиск на странице
        # название - ссылка  - какчастопроверять  1-7 - текст - нуженли прокси - последняя проверка дата - поле1 (
        # необ) Если false  то почта (с другм сообщением) навзание, ссылка лог на странице ... название - ссылка  - -
        # какчастопроверять  1-7 - текст = 0 - нуженли прокси - последняя проверка дата - поле1 об - значение 1,
        # 10 Если изменения то почта  (с другм сообщением) навзание, ссылка, как было - как стало

        # a=web.findonpage("https://band.link/scanner?search=%D0%9C%D1%8F%D1%81%D0%BD%D0%B8%D0%BA%D0%BE%D0%B2","ничего не найдено")
        # a=web.findonpage("https://band.link/scanner?search=Rayvan","ничего не найдено")

        # a=web2.findonpage("https://flibusta.is/booksearch?ask=нагибин","ничего не найдено")
        # a=web2.findonpage("https://flibusta.is/booksearch?ask=оплетаев","не найдено")
        # a=web2.findonpage("https://flibusta.site/booksearch?ask=%D0%BE%D0%BF%D0%BB%D0%B5%D1%82%D0%B0%D0%B5%D0%B2","не найдено")

        # mdriver = chromeinitilize()

        for i in db.art:
            try:
                if (i.vkstudio != ""):
                    mlink = "https://vk.com/studio#/artist/" + i.vkstudio + "/music/tracks"
                    tracks = web.getvkstudio(mlink)
                    db.vktracks2db(tracks, i.name)
                else:
                    db._dayhearsvk = db._dayaddsvk = db._dayeffvk = db._hears_best_n = db._eff_best_n =0
                    db._eff_best_song = db._hears_best_song = ""
            except:
                printsend("  " + i.name + ":VKSTUDIO : " + i.vkstudio, MTITLE + ERRORSTR)
                continue

            db.initstring(i.name)

            # Spotify требует ввода из России
            # try:
            #     if i.spot != "":
            #         mlink = "https://open.spotify.com/artist/" + i.spot
            #         db.columns["hears_month_spot"] = web.getspotifyday(mlink)
            # except:
            #     printsend(ERRORSTR +"  " + i.name + ":SPOTIFY : " +i.yandex)
            #     pass

            try:
                if i.yandex != "":
                    mlink = "https://music.yandex.ru/artist/" + i.yandex + "/info"
                    db.columns["hears_month_ynd"], db.columns["likes_month_ynd"], db.columns[
                        "likes_all_ynd"] = web.getyandexday(
                        mlink)
            except:
                printsend("  " + i.name + ":YANDEX : " + i.yandex, MTITLE + ERRORSTR)
                pass

            try:
                if i.sber != "":
                    mlink = "https://zvuk.com/artist/" + i.sber
                    db.columns["sub_sber"] = web.getsberday(mlink)
            except:
                printsend("  " + i.name + ":SBER : " + i.sber, MTITLE + ERRORSTR)
                pass

            try:
                if i.vk != "":
                    mlink = "https://vk.com/" + i.vk
                    db.columns["sub_vk"] = web.getvkday(mlink)
            except:
                printsend("  " + i.name + ":VK : " + i.vk, MTITLE + ERRORSTR)
                pass

            try:
                if i.youtube != "":
                    mlink = "https://www.youtube.com/channel/" + i.youtube
                    db.columns["sub_youtube"] = web.getyoutubeday(mlink)
            except:
                printsend("  " + i.name + ":YOUTUBE : " + i.youtube, MTITLE + ERRORSTR)
                pass

            try:
                if i.tiktok != "":
                    mlink = "https://www.tiktok.com/" + i.tiktok
                    db.columns["sub_tiktok"], db.columns["likes_tiktok"] = web.gettiktokday(mlink)
            except:
                printsend("  " + i.name + ":TIKTOK : " + i.tiktok, MTITLE + ERRORSTR)
                pass

            # # mlink = "https://open.spotify.com/artist/" + i.spot
            # # SpotifyGetDaylyStatArtist(mdriver, mconnection, mlink, i.name)

            db.day2db()

            write_file(MTITLE + " " + i.name + "  DONE")

        db.closeconnection()
        write_file(MTITLE + " End")

    except Exception as ex:
        # e = json.loads(ex.text)
        # response.status = e['payload']['message']
        printsend(ex.msg, MTITLE + ERRORSTR)
        # write_file("MUZZTAT: ERR " + ex.msg)
        # send_mail("MUZZTAT: ERR", ex.msg)


if __name__ == "__main__":
    main()
